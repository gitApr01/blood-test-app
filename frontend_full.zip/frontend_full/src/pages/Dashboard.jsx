import React from "react";
import Header from "../components/Header.jsx";
export default function Dashboard(){
  return <>
    <Header />
    <div className='card'><h2>Dashboard</h2><p>Welcome</p></div>
  </>;
}