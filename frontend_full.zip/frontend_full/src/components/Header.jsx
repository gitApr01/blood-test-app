import React from "react";
export default function Header(){
  return <div style={{padding:10,background:'#1976d2',color:'white'}}>Blood Test App</div>;
}